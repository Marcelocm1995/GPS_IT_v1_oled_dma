# STM32_OLED_SSD1306_HAL_DMA
Driver SSD1306 OLED display 0.9'' for STM32 with HAL and DMA
https://stm32withoutfear.blogspot.com/2018/04/stm32-oled-display-ssd1306-i2c.html
